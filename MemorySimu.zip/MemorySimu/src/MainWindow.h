#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QTableWidget>
#include <QTextEdit>
#include <QComboBox>
#include <QSpinBox>
#include <QLabel>
#include "MemoryBackend.h"
#include "MemoryMapWidget.h"

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

private slots:
    void onAllocate();
    void onDeallocate();
    void onReset();
    // New slot for handling clicks on the table
    void onTableClicked(int row, int col);

private:
    void setupUi();
    void updateInterface();
    void log(const QString& message, bool success = true);

    MemoryManager memoryManager;
    MemoryMapWidget* mapWidget;
    
    // UI Controls
    QComboBox* algoCombo;
    QLineEdit* pidInput;
    QSpinBox* sizeInput; 
    QLineEdit* deallocPidInput;
    QTableWidget* processTable;
    QTextEdit* eventLog;

    // New Metrics Labels
    QLabel* lblUtilPct;
    QLabel* lblFreeMem;
    QLabel* lblFragments;
    
    QList<QColor> colors;
    int colorIndex = 0;

    // --- ADDED FOR NEXT FIT FIX ---
    int lastAllocatedIndex = 0; // Tracks the pointer for Next Fit
};

#endif // MAINWINDOW_H