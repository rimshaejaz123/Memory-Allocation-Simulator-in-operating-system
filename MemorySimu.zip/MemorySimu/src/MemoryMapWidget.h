#ifndef MEMORYMAPWIDGET_H
#define MEMORYMAPWIDGET_H

#include <QWidget>
#include <QPainter>
#include "MemoryBackend.h"

class MemoryMapWidget : public QWidget {
    Q_OBJECT
public:
    explicit MemoryMapWidget(MemoryManager* manager, QWidget *parent = nullptr)
        : QWidget(parent), memoryManager(manager) {
        setMinimumHeight(100); // Height of the visual bar
        setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    }

protected:
    void paintEvent(QPaintEvent *event) override {
        Q_UNUSED(event);
        QPainter painter(this);
        
        int w = width();
        int h = height() - 20; // Reserve space for text
        int totalMem = memoryManager->totalSize;
        if (totalMem <= 0) return;

        double scale = (double)w / totalMem;

        for (const auto& block : memoryManager->blocks) {
            int x = block.startAddress * scale;
            int width = block.size * scale;
            
            // Draw Block
            QRect rect(x, 0, width, h);
            
            // Gradient effect
            QLinearGradient grad(rect.topLeft(), rect.bottomLeft());
            grad.setColorAt(0, block.color.lighter(130));
            grad.setColorAt(1, block.color);
            
            painter.setBrush(grad);
            painter.setPen(QPen(Qt::black, 1));
            painter.drawRect(rect);

            // Draw Text (Only if block is wide enough)
            if (width > 30) {
                painter.setPen(Qt::white);
                QString text = block.isFree ? "FREE" : QString::fromStdString(block.processId);
                painter.drawText(rect, Qt::AlignCenter, text);
            }
        }
        
        // Draw Ruler line
        painter.setPen(Qt::gray);
        painter.drawLine(0, h+5, w, h+5);
        painter.drawText(0, h+15, "0");
        painter.drawText(w-30, h+15, QString::number(totalMem));
    }

private:
    MemoryManager* memoryManager;
};

#endif