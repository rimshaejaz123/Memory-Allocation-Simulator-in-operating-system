#ifndef MEMORYBACKEND_H
#define MEMORYBACKEND_H

#include <list>
#include <string>
#include <vector>
#include <QColor>
#include <iterator>

// 1. Explicit Hole structure for debugging/logic
struct Hole {
    int startAddress;
    int size;
};

struct MemoryBlock {
    int startAddress;
    int size;
    bool isFree;
    std::string processId;
    QColor color;
    int endAddress() const { return startAddress + size - 1; }
};

class MemoryManager {
public:
    std::list<MemoryBlock> blocks;
    std::list<MemoryBlock>::iterator lastAllocIt;
    int totalSize;

    MemoryManager(int size = 1024) : totalSize(size) {
        reset();
    }

    void reset() {
        blocks.clear();
        // Free blocks are Bright Green (#2ecc71)
        blocks.push_back({0, totalSize, true, "FREE", QColor("#2ecc71")}); 
        lastAllocIt = blocks.begin();
    }

    // 2. Helper to get list of holes for debugging
    std::vector<Hole> getHoles() const {
        std::vector<Hole> holes;
        for(const auto& block : blocks) {
            if(block.isFree) {
                holes.push_back({block.startAddress, block.size});
            }
        }
        return holes;
    }

    // 3. MOVED TO PUBLIC: Manual Merge Function
    // You can call this manually if you add a "Compact" button to your UI.
    void mergeFreeBlocks() {
        auto it = blocks.begin();
        while (it != blocks.end()) {
            auto next = std::next(it);
            
            if (next != blocks.end() && it->isFree && next->isFree) {
                // Merge logic
                it->size += next->size;
                
                // Next Fit Pointer Protection:
                // If 'lastAllocIt' is pointing to the block we are about to delete,
                // move it to the survivor block ('it') so we don't crash.
                if (lastAllocIt == next) {
                    lastAllocIt = it;
                }
                
                blocks.erase(next);
            } else {
                ++it;
            }
        }
    }

    // --- ALGORITHMS (0=First, 1=Best, 2=Worst, 3=Next) ---
    bool allocate(const std::string& pid, int size, QColor color, int algoType) {
        auto bestIt = blocks.end();
        
        switch (algoType) {
            case 0: // First Fit
                for (auto it = blocks.begin(); it != blocks.end(); ++it) {
                    if (it->isFree && it->size >= size) { bestIt = it; break; }
                }
                break;
                
            case 1: // Best Fit
            {
                int minDiff = 999999;
                for (auto it = blocks.begin(); it != blocks.end(); ++it) {
                    if (it->isFree && it->size >= size) {
                        int diff = it->size - size;
                        if (diff < minDiff) { minDiff = diff; bestIt = it; }
                    }
                }
                break;
            }
            
            case 2: // Worst Fit
            {
                int maxDiff = -1;
                for (auto it = blocks.begin(); it != blocks.end(); ++it) {
                    if (it->isFree && it->size >= size) {
                        int diff = it->size - size;
                        if (diff > maxDiff) { maxDiff = diff; bestIt = it; }
                    }
                }
                break;
            }
            
            case 3: // Next Fit
            {
                if (lastAllocIt == blocks.end()) lastAllocIt = blocks.begin();

                auto startIt = lastAllocIt;
                int wrapped = 0; 

                do {
                    if (lastAllocIt->isFree && lastAllocIt->size >= size) {
                        bestIt = lastAllocIt; 
                        break;
                    }
                    
                    lastAllocIt++;
                    if (lastAllocIt == blocks.end()) {
                        lastAllocIt = blocks.begin();
                    }
                    
                    if (lastAllocIt == startIt) {
                        wrapped++;
                        if(wrapped > 1) break; 
                    }

                } while (lastAllocIt != startIt || bestIt == blocks.end());
                break;
            }
        }

        if (bestIt != blocks.end()) {
            splitBlock(bestIt, pid, size, color);
            // Update lastAllocIt to the new block so Next Fit continues correctly
            lastAllocIt = bestIt; 
            return true;
        }
        return false;
    }

    bool deallocate(const std::string& pid) {
        bool found = false;
        for (auto it = blocks.begin(); it != blocks.end(); ++it) {
            if (!it->isFree && it->processId == pid) {
                it->isFree = true;
                it->processId = "FREE";
                it->color = QColor("#2ecc71"); // Make freed blocks Green
                found = true;
            }
        }
        
        // 4. CHANGE APPLIED: Automatic merging DISABLED.
        // We commented this out so holes stay separate for visual clarity.
        // if (found) mergeFreeBlocks();
        
        return found;
    }

    int getUsedMemory() const {
        int used = 0;
        for(const auto& b : blocks) if(!b.isFree) used += b.size;
        return used;
    }
    
    int getFragmentationCount() const {
        int holes = 0;
        for(const auto& b : blocks) if(b.isFree) holes++;
        return holes;
    }

private:
    void splitBlock(std::list<MemoryBlock>::iterator it, std::string pid, int size, QColor color) {
        int originalSize = it->size;
        int originalStart = it->startAddress;
        
        it->size = size;
        it->isFree = false;
        it->processId = pid;
        it->color = color;

        if (originalSize > size) {
            MemoryBlock newFree;
            newFree.startAddress = originalStart + size;
            newFree.size = originalSize - size;
            newFree.isFree = true;
            newFree.processId = "FREE";
            newFree.color = QColor("#2ecc71"); 
            
            // Insert the new free block AFTER the allocated one
            blocks.insert(std::next(it), newFree);
        }
    }
};

#endif