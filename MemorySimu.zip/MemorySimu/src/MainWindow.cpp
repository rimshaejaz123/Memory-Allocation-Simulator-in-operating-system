#include "MainWindow.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QHeaderView>
#include <QFrame>
#include <QGroupBox>
#include <QTabWidget>
#include <QDateTime>
#include <QScrollBar> 

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    // TARGET IMAGE COLORS: Blue, Orange, Purple, then others
    colors << QColor("#007acc") << QColor("#ff8c00") << QColor("#9b59b6") 
           << QColor("#e74c3c") << QColor("#f1c40f") << QColor("#34495e");
    setupUi();
    updateInterface(); 
}

void MainWindow::setupUi() {
    setWindowTitle("Memory Allocation Simulator v1.0");
    resize(1150, 750);

    QWidget* central = new QWidget;
    setCentralWidget(central);
    QHBoxLayout* mainLayout = new QHBoxLayout(central);
    mainLayout->setSpacing(20);
    mainLayout->setContentsMargins(20, 20, 20, 20);

    // ================= LEFT SIDEBAR (CONTROLS) =================
    QFrame* sidePanel = new QFrame;
    sidePanel->setObjectName("MainContentFrame");
    sidePanel->setFixedWidth(280);
    QVBoxLayout* sideLayout = new QVBoxLayout(sidePanel);

    QLabel* ctrlTitle = new QLabel("<b>Controls</b>");
    ctrlTitle->setStyleSheet("font-size: 12pt; margin-bottom: 10px; color: #fff;");
    sideLayout->addWidget(ctrlTitle);
    
    // Algorithm Dropdown
    sideLayout->addWidget(new QLabel("Algorithm:"));
    algoCombo = new QComboBox;
    algoCombo->addItems({"First Fit", "Best Fit", "Worst Fit", "Next Fit"});
    sideLayout->addWidget(algoCombo);
    sideLayout->addSpacing(15);

    // TABS
    QTabWidget* tabWidget = new QTabWidget;
    
    // -- Tab 1: Allocate --
    QWidget* tabAlloc = new QWidget;
    QVBoxLayout* layAlloc = new QVBoxLayout(tabAlloc);
    layAlloc->setContentsMargins(10,15,10,10);
    layAlloc->addWidget(new QLabel("Process ID:"));
    pidInput = new QLineEdit;
    pidInput->setPlaceholderText("P1");
    layAlloc->addWidget(pidInput);
    layAlloc->addWidget(new QLabel("Size:"));
    sizeInput = new QSpinBox;
    sizeInput->setRange(1, memoryManager.totalSize);
    sizeInput->setValue(100);
    sizeInput->setSuffix(" KB");
    layAlloc->addWidget(sizeInput);
    layAlloc->addSpacing(10);
    QPushButton* btnAlloc = new QPushButton("ALLOCATE");
    btnAlloc->setStyleSheet("background-color: #28a745; color: white; font-weight: bold; padding: 12px; border-radius: 4px;");
    connect(btnAlloc, &QPushButton::clicked, this, &MainWindow::onAllocate);
    layAlloc->addWidget(btnAlloc);
    layAlloc->addStretch();
    tabWidget->addTab(tabAlloc, "Allocate");

    // -- Tab 2: Deallocate --
    QWidget* tabFree = new QWidget;
    QVBoxLayout* layFree = new QVBoxLayout(tabFree);
    layFree->setContentsMargins(10,15,10,10);
    layFree->addWidget(new QLabel("Process ID to Kill:"));
    deallocPidInput = new QLineEdit;
    deallocPidInput->setPlaceholderText("Select from table...");
    layFree->addWidget(deallocPidInput);
    layFree->addSpacing(10);
    QPushButton* btnFree = new QPushButton("DEALLOCATE");
    btnFree->setStyleSheet("background-color: #dc3545; color: white; font-weight: bold; padding: 12px; border-radius: 4px;");
    connect(btnFree, &QPushButton::clicked, this, &MainWindow::onDeallocate);
    layFree->addWidget(btnFree);
    layFree->addStretch();
    tabWidget->addTab(tabFree, "Deallocate");

    sideLayout->addWidget(tabWidget);
    
    // Speed Slider
    sideLayout->addSpacing(25);
    sideLayout->addWidget(new QLabel("Simulation Speed"));
    QSlider* speedSlider = new QSlider(Qt::Horizontal);
    speedSlider->setValue(50);
    sideLayout->addWidget(speedSlider);
    QLabel* speedLbl = new QLabel("Medium");
    speedLbl->setAlignment(Qt::AlignCenter);
    speedLbl->setStyleSheet("color: #888; font-size: 8pt;");
    sideLayout->addWidget(speedLbl);
    sideLayout->addStretch();
    mainLayout->addWidget(sidePanel);

    // ================= RIGHT DASHBOARD =================
    QVBoxLayout* rightLayout = new QVBoxLayout;

    // --- 1. HEADER ---
    QHBoxLayout* headerLay = new QHBoxLayout;
    QLabel* title = new QLabel("Memory Allocation Simulator v1.0");
    title->setStyleSheet("font-size: 18pt; font-weight: bold; color: #e0e0e0;");
    headerLay->addWidget(title);
    headerLay->addStretch();
    
    // Label for Total RAM
    QLabel* ramLbl = new QLabel("Total RAM: ");
    ramLbl->setStyleSheet("color: #aaa; margin-right: 5px;");
    headerLay->addWidget(ramLbl);

    // Input for RAM
    QLineEdit* ramDisp = new QLineEdit("1024 KB");
    ramDisp->setReadOnly(true);
    ramDisp->setAlignment(Qt::AlignCenter);
    ramDisp->setStyleSheet("background-color: #333; border: 1px solid #555; border-radius: 4px; padding: 4px; color: white;");
    ramDisp->setFixedWidth(80);
    headerLay->addWidget(ramDisp);
    
    // Set Button (fixed width)
    QPushButton* btnSet = new QPushButton("[Set]");
    btnSet->setFixedWidth(50);
    btnSet->setStyleSheet("background-color: #444; border: none; color: #ccc;");
    headerLay->addWidget(btnSet);

    // --- NEW FEATURE: Compact Button (Manual Merge) ---
    // Since we disabled auto-merge, this button lets you merge holes manually.
    QPushButton* btnCompact = new QPushButton(" Compact");
    btnCompact->setStyleSheet("background-color: #f1c40f; color: black; padding: 6px 15px; border-radius: 4px; font-weight: bold;");
    // Using a Lambda function so you don't need to change the Header file
    connect(btnCompact, &QPushButton::clicked, [this](){
        memoryManager.mergeFreeBlocks();
        updateInterface();
        log("Memory compacted manually. Holes merged.", true);
    });
    headerLay->addWidget(btnCompact);

    // Reset Button
    QPushButton* btnReset = new QPushButton(" Reset Simulation");
    btnReset->setObjectName("ResetButton");
    btnReset->setStyleSheet("background-color: #d32f2f; color: white; padding: 6px 15px; border-radius: 4px; font-weight: bold;");
    connect(btnReset, &QPushButton::clicked, this, &MainWindow::onReset);
    headerLay->addWidget(btnReset);
    rightLayout->addLayout(headerLay);

    // --- 2. MAP ---
    QFrame* mapFrame = new QFrame;
    mapFrame->setObjectName("MainContentFrame");
    QVBoxLayout* mapLay = new QVBoxLayout(mapFrame);
    mapLay->addWidget(new QLabel("<b>Memory Map Visualization</b>"));
    mapWidget = new MemoryMapWidget(&memoryManager);
    mapLay->addWidget(mapWidget);
    rightLayout->addWidget(mapFrame);

    // --- 3. TABLE ---
    QFrame* tableFrame = new QFrame;
    tableFrame->setObjectName("MainContentFrame");
    QVBoxLayout* tableLay = new QVBoxLayout(tableFrame);
    tableLay->addWidget(new QLabel("<b>Active Process Table</b>"));
    
    processTable = new QTableWidget(0, 5);
    processTable->setHorizontalHeaderLabels({"ID", "Color", "Size", "Start", "End"});
    processTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    processTable->verticalHeader()->setVisible(false);
    processTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    processTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    processTable->setFixedHeight(180);
    connect(processTable, &QTableWidget::cellClicked, this, &MainWindow::onTableClicked);
    tableLay->addWidget(processTable);
    rightLayout->addWidget(tableFrame);

    // --- 4. BOTTOM ---
    QHBoxLayout* bottomLay = new QHBoxLayout;

    // Log
    QFrame* logFrame = new QFrame;
    logFrame->setObjectName("MainContentFrame");
    QVBoxLayout* logLayBox = new QVBoxLayout(logFrame);
    logLayBox->addWidget(new QLabel("<b>Event Log</b>"));
    eventLog = new QTextEdit;
    eventLog->setReadOnly(true);
    eventLog->setStyleSheet("border:none; background-color: transparent; font-family: Consolas; font-size: 9pt; color: #ccc;");
    logLayBox->addWidget(eventLog);
    bottomLay->addWidget(logFrame, 65); 

    // Metrics
    QFrame* metricsFrame = new QFrame;
    metricsFrame->setObjectName("MainContentFrame");
    QVBoxLayout* metLay = new QVBoxLayout(metricsFrame);
    metLay->addWidget(new QLabel("<b>Metrics</b>"));
    
    QHBoxLayout* metricBoxLay = new QHBoxLayout;
    lblUtilPct = new QLabel("0%");
    lblUtilPct->setAlignment(Qt::AlignCenter);
    lblUtilPct->setFixedSize(80, 80);
    lblUtilPct->setStyleSheet("border: 6px solid #007acc; border-radius: 40px; font-size: 18pt; font-weight:bold; color: white;");
    
    QVBoxLayout* textMetLay = new QVBoxLayout;
    lblFragments = new QLabel("Ext. Fragmentation:\n0 KB");
    lblFragments->setStyleSheet("font-size: 11pt; color: #ddd;");
    lblFreeMem = new QLabel("Holes:\n0");
    lblFreeMem->setStyleSheet("font-size: 11pt; color: #ddd;");
    
    textMetLay->addWidget(lblFragments);
    textMetLay->addWidget(lblFreeMem);
    metricBoxLay->addWidget(lblUtilPct);
    metricBoxLay->addSpacing(20);
    metricBoxLay->addLayout(textMetLay);
    metLay->addLayout(metricBoxLay);
    bottomLay->addWidget(metricsFrame, 35); 

    rightLayout->addLayout(bottomLay);
    mainLayout->addLayout(rightLayout);
}

// --- LOGIC ---
void MainWindow::onAllocate() {
    QString pid = pidInput->text();
    int size = sizeInput->value();
    if (pid.isEmpty() || size <= 0) return;

    QColor color = colors[colorIndex % colors.size()];
    int algo = algoCombo->currentIndex(); 

    bool success = memoryManager.allocate(pid.toStdString(), size, color, algo);
    QString algoName = algoCombo->currentText();
    if (success) {
        log("Allocated " + QString::number(size) + "KB for " + pid + " (" + algoName + "). Success.", true);
        colorIndex++;
        pidInput->clear();
    } else {
        log("FAILED to allocate " + QString::number(size) + "KB for " + pid + ". No suitable hole.", false);
    }
    updateInterface();
}

void MainWindow::onDeallocate() {
    QString pid = deallocPidInput->text();
    if (pid.isEmpty()) return;

    bool success = memoryManager.deallocate(pid.toStdString());
    if (success) {
        log("Process " + pid + " deallocated. Memory freed.", true);
        deallocPidInput->clear();
    } else {
        log("Error: Process " + pid + " not found.", false);
    }
    updateInterface();
}

void MainWindow::onReset() {
    memoryManager.reset();
    log("Simulation Reset.");
    colorIndex = 0;
    updateInterface();
}

void MainWindow::onTableClicked(int row, int col) {
    Q_UNUSED(col);
    QString pid = processTable->item(row, 0)->text();
    deallocPidInput->setText(pid);
}

void MainWindow::log(const QString& msg, bool success) {
    QString time = QDateTime::currentDateTime().toString("[hh:mm:ss] ");
    QString color = success ? "#e0e0e0" : "#ff5555";
    eventLog->append("<span style='color:#888'>" + time + "</span> <span style='color:" + color + "'>" + msg + "</span>");
    eventLog->verticalScrollBar()->setValue(eventLog->verticalScrollBar()->maximum());
}

void MainWindow::updateInterface() {
    mapWidget->update();
    processTable->setRowCount(0);
    for (const auto& b : memoryManager.blocks) {
        if (!b.isFree) {
            int r = processTable->rowCount();
            processTable->insertRow(r);
            processTable->setItem(r, 0, new QTableWidgetItem(QString::fromStdString(b.processId)));
            QTableWidgetItem* cItem = new QTableWidgetItem;
            cItem->setBackground(b.color);
            processTable->setItem(r, 1, cItem);
            processTable->setItem(r, 2, new QTableWidgetItem(QString::number(b.size)));
            processTable->setItem(r, 3, new QTableWidgetItem(QString::number(b.startAddress)));
            processTable->setItem(r, 4, new QTableWidgetItem(QString::number(b.endAddress())));
        }
    }

    int used = memoryManager.getUsedMemory();
    int total = memoryManager.totalSize;
    
    // This now counts individual green strips since we disabled auto-merge
    int holes = memoryManager.getFragmentationCount(); 
    
    int util = (int)((double)used / total * 100);

    lblUtilPct->setText(QString::number(util) + "%");
    QString borderColor = util > 80 ? "#e74c3c" : "#007acc";
    lblUtilPct->setStyleSheet("border: 6px solid " + borderColor + "; border-radius: 40px; font-size: 18pt; font-weight:bold; color: white;");
    lblFragments->setText("Ext. Fragmentation:\n" + QString::number(total - used) + " KB");
    lblFreeMem->setText("Holes:\n" + QString::number(holes));
}